public class DtheHView{

public void body(){

  System.out.println("--------");
  System.out.println("|      |");
  System.out.println("|      |");
  System.out.println("--------");


}

public void roof(){
  System.out.println("   /\\  ");
  System.out.println("  /  \\  ");
  System.out.println(" /    \\ ");

}

public void door(){
  System.out.println("--------");
  System.out.println("|      |");
  System.out.println("|  | | |");
  System.out.println("--------");


}

public void windows(){
  System.out.println("---------");
  System.out.println("| X   X |");
  System.out.println("|  | |  |");
  System.out.println("--------");


}



}
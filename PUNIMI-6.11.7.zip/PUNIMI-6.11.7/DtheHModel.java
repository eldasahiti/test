public class DtheHModel{


   public boolean house = false;
   public boolean body = false;
   public boolean roof = false;
   public boolean door = false;
   public boolean windows = false;





}
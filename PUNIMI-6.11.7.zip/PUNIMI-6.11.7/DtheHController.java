public class DtheHController{
   public static void main(String args[]){
   int zari;
   DtheHModel model = new DtheHModel();
   DtheHView view = new DtheHView();
   
       while(!model.house){
   
  zari = (int)(Math.random() * 6) + 1;
  System.out.println("zari =" + zari);
  
  if(zari == 6  && !model.body){
   view.body();
    model.body = true;

  }
  
  if(zari == 5 && model.body && !model.roof ){
   view.roof();
   view.body();

   
    model.roof = true;

  }
  
  
  if(zari == 4 && model.body && model.roof && !model.door ){
   view.roof();
   view.door();
   model.door = true;
  }
  
  if(zari == 3 && model.body && model.roof && !model.windows){
     model.windows  = true;
  }
  
   
   if(model.body && model.roof && model.door && model.windows){
   view.roof();
   view.windows();
   model.house = true;
   
   }
   
   
   }
   
   
   }


}